export default function Casual() {
    return (
        <div>
            <h1>Casual</h1>
        </div>
    )
}