export default function Meias() {
    return (
        <div>
            <h1>Meias</h1>
        </div>
    )
}