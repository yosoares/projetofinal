export default function Academia() {
    return (
        <div>
            <h1>Academia</h1>
        </div>
    )
}