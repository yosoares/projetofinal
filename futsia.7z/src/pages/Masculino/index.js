export default function Masculino() {
    return (
        <div>
            <h1>Masculino</h1>
        </div>
    )
}