export default function Esportes() {
    return (
        <div>
            <h1>Esportes</h1>
        </div>
    )
}