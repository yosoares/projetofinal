export default function Basquete() {
    return (
        <div>
            <h1>Basquete</h1>
        </div>
    )
}