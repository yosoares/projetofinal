export default function Volei() {
    return (
        <div>
            <h1>Vôlei</h1>

        </div>
    )
}