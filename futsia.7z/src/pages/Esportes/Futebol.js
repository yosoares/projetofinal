export default function Futebol() {
    return (
        <div>
            <h1>Futebol</h1>
        </div>
    )
}