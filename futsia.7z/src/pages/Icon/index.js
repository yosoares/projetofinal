export default function Icon() {
    return (
        <div>
            <h1>home home</h1>
        </div>

    )
}