export default function Vendas() {
    return (
        <div>
            <h1>Vendas Digitais</h1>
        </div>
    )
}