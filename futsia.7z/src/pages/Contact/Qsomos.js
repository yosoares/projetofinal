export default function Qsomos() {
    return (
        <div>
            <h1>Um pouco</h1>
        </div>
    )
}