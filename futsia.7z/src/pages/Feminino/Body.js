
export default function Body() {
    return (
        <div>
            <h1>Body Fitness</h1>
        </div>
    )
}