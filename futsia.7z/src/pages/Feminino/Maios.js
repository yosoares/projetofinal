
export default function Maios() {
    return (
        <div>
            <h1>Maiôs</h1>
        </div>
    )
}