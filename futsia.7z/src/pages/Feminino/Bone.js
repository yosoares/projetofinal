
export default function Bone() {
    return (
        <div>
            <h1>Boné</h1>
        </div>
    )
}