export default function Calças() {
    return (
        <div>
            <h1>Calças</h1>
        </div>
    )
}