export default function Roupas() {
    return (
        <div>
            <h1>Roupas</h1>
        </div>
    )
}