export default function Proteçao() {
    return (
        <div>
            <h1>Joelheira</h1>
        </div>
    )
}