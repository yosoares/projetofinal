export default function Blusas() {
    return (
        <div>
            <h1>Blusas</h1>
        </div>
    )
}