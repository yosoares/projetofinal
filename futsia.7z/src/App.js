import Rotas from './routes'
import './index.css'


function App() {

  return (
    <div>
      <Rotas />
    </div>
  );
}

export default App;
